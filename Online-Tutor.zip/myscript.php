<?php
if(isset($_POST['submitted'])){
	//if($_POST["submitted"])
{
	//run php script here
	echo "HHHHHHHH";
}
}

?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form method="post">
		<input type="hidden" name="submitted">
		<button type="submit"> Run the script! </button>
	</form>
</body>
</html>