<?php
session_start();
 $db = mysqli_connect('localhost','root','','test_db')
 or die('Error connecting to MySQL server.');
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<title>OnlineTutor</title>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="HomeStyle.css">
		<link rel="stylesheet" href="OtherPageStyle.css">
	</head>
	<body>

		<div class="header">
		  <h1>Online Tutor</h1>
		  
		</div>

		<div class="navbar">
		  <a href="Index.php">Home</a>
		  <a href="Courses.php">Courses</a>
		  <a href="About.php">About</a>
		  <a href="Contact.php">Contact us</a>
			<?php
				if(empty($_SESSION)==true){
					echo '<a href="Login.php">Log in</a>';
					echo '<a href="SignUp.php">Sign up</a>';
				}
				else{
					if($_SESSION['card']=="student") echo '<a href="StudentProfile.php">My profile</a>';
					else if($_SESSION['card']=="instructor") echo '<a href="InstructorProfile.php">My profile</a>';
					echo '<a href="logout.php">Log out</a>';
				} 	
			?>
		</div>
		
		
		<div class="row">
		    <div class="tab">
			<?php 
			
			  $curr_ins_id = $_SESSION['ins_id'];
					$query = "select * from course natural join content where ins_id='$curr_ins_id';";
					
					$course_query = mysqli_query($db,$query) or die('Error querying database.');
					
					
					while ($row = $course_query->fetch_assoc()) {
						
						$course_link = $row["clink"];
						$crscd = $row["course_code"];
						
						echo nl2br("\n\n\n" . $row["content_id"] . " " . $row["content_name"] ." "  );
						echo "<a href='SingleCourse.php?variable="."$crscd'>Link</a>";
							
					}
					echo nl2br("\n\n\n");
					?>
		    </div>
			
			<?php
			
			$crs = $_POST['crscd'];
			$cnt = $_POST['cntcd'];
			
			$theq = "select link from content where course_code = $crs and content_id = $cnt;";
			
			$ret_query = mysqli_query($db,$theq) or die('Error querying database.');
			$therow = mysqli_fetch_row();
			$the_link = $therow['link'];
			
			if ($handle = opendir('.')) {

				while (false !== ($entry = readdir($the_link))) {

					if ($entry != "." && $entry != "..") {

						echo "$entry\n";
					}
				}

				closedir($handle);
			}		
			
		  
		  ?>
		
		
	</body>
	
</html>